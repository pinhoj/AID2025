# AID2025
Projeto de Análise e Integração de Dados
